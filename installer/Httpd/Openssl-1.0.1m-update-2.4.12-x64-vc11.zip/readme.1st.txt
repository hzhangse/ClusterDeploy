 
  March 20, 2015
                                  Apache Haus Distribution 
                        
  Application:       OpenSSL 1.0.1m update for Apache 2.4.12 x64
  Distribution File: openssl-1.0.1m-update-2.4.12-x64-vc11.zip 
 
  Original source by: OpenSSL
  Original Home:      http://www.openssl.org
  
  Original source by: Apache Software Foundation 
  Original Home:      http://httpd.apache.org 
  
  Mail:            info@apachehaus.com 
  Home:            http://www.apachehaus.com 

  OpenSSL Version: 1.0.1m+asm 
  
  Modules built on Visual C++ 2012 x64 do not run on Windows XP or Windows Server 2003

  The module is built with Visual Studio� 2012 x64, be sure to install the 
  new Visual C++ 2012  x64 Redistributable Package, download from;

  http://www.microsoft.com/en-us/download/details.aspx?id=30679


  Supported Windows Versions:

    Windows Vista x64
    Windows Server 2008 x64
    Windows 7 x64
    Windows Server 2012 x64
    Windows 8/8.1 x64
  
  
  Files Included:

    readme.1st.txt (this file)
    Apache24/LICENSE.txt
    Apache24/OPENSSL-README.txt
    Apache24/bin/abs.exe
    Apache24/bin/apr_crypto_openssl-1.dll
    Apache24/bin/libeay32.dll
    Apache24/bin/ssleay32.dll
    Apache24/bin/openssl.exe
    Apache24/conf/openssl.cnf
    Apache24/modules/mod_ssl.so
  

  Update Apache 2.4.12 x64 to OpenSSL 1.0.1m
  ------------------
    Simply replace your existing files with the ones in this package
    Remember to make a backup of the original files before replacing.

    /Apache24/bin/abs.exe
    /Apache24/bin/apr_crypto_openssl-1.dll
    /Apache24/bin/openssl.exe
    /Apache24/bin/libeay32.dll
    /Apache24/bin/ssleay32.dll

    /Apache24/conf/openssl.cnf

    /Apache24/modules/mod_ssl.so



    If you have questions, want more info or need help troubleshooting problems
    post in the our forum at http://www.apachehaus.com
  

  Legal notes:
  =============================================================================
   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
   EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
   MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
   IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
   CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
   TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
   SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

   This distribution includes cryptographic software.  The country in which you 
   are currently may have restrictions on the import, possession, and use, 
   and/or re-export to another country, of encryption software.  BEFORE using 
   any encryption software, please check the country's laws, regulations and 
   policies concerning the import, possession, or use, and re-export of encryption
   software, to see if this is permitted.

   The U.S. Government Department of Commerce, Bureau of Industry and Security (BIS), 
   has classified this software as Export Commodity Control Number (ECCN) 5D002.C.1, 
   which includes information security software using or performing cryptographic 
   functions with asymmetric algorithms.  The form and manner of this distribution 
   makes it eligible for export under the License Exception ENC Technology Software 
   Unrestricted (TSU) exception (see the BIS Export Administration Regulations, 
   Section 740.13) for both object code and source code. 

   The authors of the represented software packages and and the Apache Haus, are 
   not liable for any violations you make. Be careful, it is solely your responsibility. 

